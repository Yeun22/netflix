<header>
	<div id="brand"><img src="img/logo.png" alt="Netflix"></div>
</header>