<footer>
	<div class="container">
		<p>Des questions ? Appelez le 0800 917 813</p>
		<a href="#">Conditions des cartes cadeaux</a>
		<a href="#">Conditions d'utilisation</a>
		<a href="#">Déclaration de confidentialité</a>
	</div>
</footer>