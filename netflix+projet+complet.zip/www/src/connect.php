<?php
	
	$db = new PDO('mysql:host=localhost;dbname=netflix;charset=utf8', 'root', '');

?>